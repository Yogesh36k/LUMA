class SearchPage {
    
    search(query) {
      
    cy.get("#search").clear().type(`${query}{enter}`); // Replace with actual search box selector
    }
  
    // verifyResults(query) {
    //   cy.contains(`Search results for: '${query}'`);

    // }

  }
  
  export default SearchPage;
  