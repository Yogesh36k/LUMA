///<reference types="cypress" />
class productfilter{

    searchandfilter(){


        cy.get('[id="ui-id-4"').trigger('mouseover');

        cy.get('[id="ui-id-9"]').trigger('mouseover');
        
        cy.xpath("(//li[@class='level2 nav-2-1-1 category-item first ui-menu-item'])[1]").click()
        
    }

    productpage(){

        cy.get("#sorter").select(1).should('have.value',"name").should('be.visible')

        cy.get("#sorter").select(2).should('have.value',"price").should('be.visible')

        cy.get("#sorter").select(0).should('have.value',"position").should('be.visible')

        cy.get("#sorter").select(1).should('have.value',"name").should('be.visible')

    }

    clothsizes(){

        cy.xpath("//img[@alt='Adrienne Trek Jacket']").trigger("mouseover");

        cy.xpath("//div[@class='swatch-opt-1316']//div[@id='option-label-size-143-item-166']").click()

        cy.xpath("//div[@class='swatch-opt-1316']//div[@id='option-label-size-143-item-167']").click()

        cy.xpath("//div[@class='swatch-opt-1316']//div[@id='option-label-size-143-item-168']").click()

        cy.xpath("//div[@class='swatch-opt-1316']//div[@id='option-label-size-143-item-169']").click()

        cy.xpath("//div[@class='swatch-opt-1316']//div[@id='option-label-size-143-item-170']").click()

        cy.get('.swatch-opt-1316 > .swatch-attribute.color > .swatch-attribute-options > #option-label-color-93-item-56').click()

    }
}
export default productfilter;