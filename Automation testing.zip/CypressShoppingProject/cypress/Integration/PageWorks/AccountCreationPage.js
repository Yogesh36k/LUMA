class Accounts{

    createaccount(){     

        cy.xpath("(//*[@href='https://magento.softwaretestingboard.com/customer/account/create/'])[1]").click()

        cy.xpath("(//*[.='Create New Customer Account'])[2]").should('be.visible')

        cy.get('#firstname').type('Test')   
        
        cy.get('#lastname').type('User')

        cy.get('#email_address').type('Test@gail.co')

        cy.get('#password').type('TestUser')

        cy.get('#password-confirmation').type('TestUser')

        // cy.get('[title="Create an Account"]').click()
        
    }

    signintoaccount(){

        cy.xpath('(//*[@href="https://magento.softwaretestingboard.com/customer/account/login/referer/aHR0cHM6Ly9tYWdlbnRvLnNvZnR3YXJldGVzdGluZ2JvYXJkLmNvbS8%2C/"])[1]').click()

        cy.xpath("(//*[@role='heading'])[1]").should('have.text','Registered Customers')

        cy.get('#email').type('Test@gail.co')

        cy.get('#pass').type('User')

        // cy.xpath("(//*[@name='send'])[1]").click()
    }

}
export default Accounts;