class cartprocess{


    searchandfilter(){


        cy.get('[id="ui-id-4"').trigger('mouseover');

        cy.get('[id="ui-id-9"]').trigger('mouseover');
        
        cy.xpath("(//li[@class='level2 nav-2-1-1 category-item first ui-menu-item'])[1]").click()
        
    }

    
    clothsizes(){

        cy.xpath("//img[@alt='Adrienne Trek Jacket']").trigger("mouseover");

        cy.xpath("//div[@class='swatch-opt-1316']//div[@id='option-label-size-143-item-166']").click()
}