///<reference types="cypress" />

class initialpage{

    homepage(){

        cy.visit('https://magento.softwaretestingboard.com/')
        // cy.title().should('eq','Home Page')
        // cy.wait(500)
    };

    menuitems(){

        cy.get('#ui-id-3').click()
        cy.get('[aria-label="store logo"]').click()
        cy.get('#ui-id-4').click()
        cy.get('[aria-label="store logo"]').click()
        cy.get('#ui-id-5').click()
        cy.get('[aria-label="store logo"]').click()
        cy.get('#ui-id-6').click()
        cy.get('[aria-label="store logo"]').click()
        cy.get('#ui-id-7').click()
        cy.get('[aria-label="store logo"]').click()
        cy.get('#ui-id-8').click()
        cy.get('[aria-label="store logo"]').click()
        cy.get('[src="https://magento.softwaretestingboard.com/pub/media/wysiwyg/home/home-main.jpg"]').should('be.visible')

}
      FooterCheck(){

         cy.xpath("(//*[.='Privacy and Cookie Policy'])[1]").should('be.visible')
         cy.xpath("(//*[.='Privacy and Cookie Policy'])[1]").click()
         cy.xpath("(//*[.='Luma Privacy Policy'])[1]").then(($ele) => {

            if($ele.text()=="Luma Privacy Policy"){

                cy.wrap($ele).click()

                cy.go('back')
            }
            
         })

      }
}
export default initialpage;