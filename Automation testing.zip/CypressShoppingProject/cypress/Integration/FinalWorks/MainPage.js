///<reference types='cypress' />
import initialpage from "../PageWorks/Homepage";
import Accounts from "../PageWorks/AccountCreationPage";
import SearchPage from "../PageWorks/SearchFunctionalityCheck";
import productfilter from "../PageWorks/ProductFilters";

describe('Main Page', function(){

    const ip = new initialpage();

    const ac = new Accounts();

    const searchPage = new SearchPage();

    const pf = new productfilter();

    this.beforeEach(()=>{

        ip.homepage()
    })

    it.only('Product Filter', ()=>{

        pf.searchandfilter();
        pf.productpage();
        pf.clothsizes()
    }
  )

    it('Home Page', ()=>{

        ip.menuitems();
        ip.FooterCheck();
    })

    it.skip('Account Creation', ()=>{

        ac.createaccount();
        cy.go('back');
        ac.signintoaccount();
    })

    it("Tests multiple search queries", function () {
        cy.fixture("searchdata").then((data) => {
          data.queries.forEach((query) => {
            searchPage.search(query);
            // searchPage.verifyResults(query);
            cy.reload(); // Reload the page for the next test
          });
        });
      });

    
}

    
)





 
